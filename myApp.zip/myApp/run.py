from app import app

if __name__ =="__main__":
	app.run(debug= True)

"""
- The first app refers to your folder name (app/)
→ Python treats this folder as a package because it has a file name
 __init__.py.

- The second app refers to the Flask application object that’s defined
 inside app/__init__.py.

So that line means:

“Import the Flask application object (app) from the package located in the 
folder named app"


"""
