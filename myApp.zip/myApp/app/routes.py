from flask import render_template, request, redirect, url_for, flash, session
from app import app
"""
render_template → load an HTML file (like home.html)

request → access form data or query parameter
 (like request.form.get('username'))

redirect → send the user to another rout

 (like redirect(url_for('dashboard')))

url_for → build URLs dynamically using function name
 (instead of hardcoding /dashboard)

flash → show temporary messages to the use
 (like “Login successful!”)

session → store small pieces of user data (like who’s logged in)
"""


LISTINGS = [
    {"id": 1, "title": "Cozy Apartment", "price": "$1200", "location": "San Jose", "description": "Perfect for students"},
    {"id": 2, "title": "Modern Condo", "price": "$1800", "location": "Santa Clara", "description": "Close to downtown"},
    {"id": 3, "title": "Spacious Home", "price": "$2500", "location": "Sunnyvale", "description": "Family-friendly area"},
    {"id": 4, "title": "Luxury Villa", "price": "$5000", "location": "Los Gatos", "description": "Private pool and garden"},
    {"id": 5, "title": "Downtown Loft", "price": "$2300", "location": "San Jose", "description": "Walk to cafes and shops"},
    {"id": 6, "title": "Suburban Townhouse", "price": "$2100", "location": "Milpitas", "description": "Quiet neighborhood with parks nearby"},
    {"id": 7, "title": "Studio Flat", "price": "$950", "location": "Campbell", "description": "Compact and affordable with modern finishes"},
    {"id": 8, "title": "Beachside Cottage", "price": "$3200", "location": "Santa Cruz", "description": "Ocean views and a short walk to the beach"},
    {"id": 9, "title": "Mountain Cabin", "price": "$2800", "location": "Los Altos Hills", "description": "Rustic charm surrounded by nature"},
    {"id": 10, "title": "Penthouse Suite", "price": "$6200", "location": "Palo Alto", "description": "Top-floor luxury with panoramic city views"},
]


#---Home page ---
@app.route("/")
def home():
    return render_template("home.html", title="Home")


@app.route("/listings")
def listings():
    return render_template("listings.html", title="Listings", listings=LISTINGS)


#dynamic URL: /listing/1
#listing_detail(1)
#1 : represents the ID of a specific listing in your LISTINGS list.
@app.route("/listing/<int:item_id>")
def listing_detail(item_id):
    # listing = next((l for l in LISTINGS if l["id"] == item_id), None)
    
    for x in LISTINGS:
        if x["id"] == item_id:
            listing = x
            break
    else:
        listing = None
    #loops through all items in LISTINGS, finds the one where id == item_id,
    #and stores it in listing
    
    if not listing:
        flash("Listing not found.")
        return redirect(url_for("listings"))
    return render_template("listing_detail.html", title=listing["title"], listing=listing)

    #Ex: listing= {"id": 1, "title": "Cozy Apartment", "price": "$1200", "location": "San Jose", "description": "Perfect for students"}
    # title = "Cozy Apartment"
	


#GET → when you just visit /login in your browser (shows the form)
#POST → when you submit the form (processes login data)
@app.route("/login", methods=["GET", "POST"])
#if User first visits /login (just opens the page):
#if request.method == "POST": is False, because this is a GET request.
#So the code skips everything inside that if, else  block
#and directly jumps to: return render_template("login.html", title="Login")
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
    
        if username and password:
            session["user"] = {"username": username}
            flash(f"Welcome, {username}! (mock login)")
            return redirect(url_for("dashboard"))
        else:
            flash("Please enter a username and password.")
            return redirect(url_for("login"))

    return render_template("login.html", title="Login")
			

"""
1. Note 1
username = request.form.get("username", "").strip()
password = request.form.get("password", "").strip()

If both fields are filled → Flask saves info in session, flashes message, and redirects to /dashboard.

If either is missing → Flask flashes an error and redirects back to /login.(else part)


2. Note 2

session["user"] = {"username": username}

creating a nested structure like: a dictionary inside a dictionary.

session = {
    "user": {
        "username": "Alice"
    }
}

3. Note 3

request.form.get(): During a POST request (when a user submits a form)
Reads data sent from the browser
Get username/password from a login form
"""

"""
session.get():After login, on later pages	
Retrieves data you stored earlier in the session
Show “Welcome, Alice” on dashboard
"""

# ---- Dashboard ----
@app.route("/dashboard")
def dashboard():
    user = session.get("user")  
    return render_template("dashboard.html", title="Dashboard", user=user)
   


# ---- Optional: simple logout to clear session ----
@app.route("/logout")
def logout():
    session.pop("user", None)
    flash("Logged out (mock).")
    return redirect(url_for("home"))
