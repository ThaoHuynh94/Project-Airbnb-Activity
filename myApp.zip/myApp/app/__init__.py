from flask import Flask

app = Flask (__name__)

app.config["SECRET_KEY"] = "Mydreamwillcometrue94"
# needed for flashing messages/sessions

from app import routes
#activates (registers) all the route functions (@app.route(...))
#you define in your routes.py file.

"""
from flask import Flask
import secrets  #  needed here

app = Flask(__name__)
app.config["SECRET_KEY"] = secrets.token_hex(32)

from app import routes

make the secret more secure and random:

import secrets is required,
since you’re calling secrets.token_hex(32) to generate a random
 64-character key.
"""


